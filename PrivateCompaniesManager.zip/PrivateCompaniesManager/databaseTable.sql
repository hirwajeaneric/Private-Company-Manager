CREATE TABLE companies (
    registrationNo int(4) PRIMARY KEY NOT NULL,
    companyName VARCHAR(45),
    category VARCHAR(45),
    owner VARCHAR(45),
    startingDate VARCHAR(45),
    registrationDate DATE,
    capital INT
);
