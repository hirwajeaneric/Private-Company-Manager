package model;

import java.util.Date;

public class Companies {
    private int registrationNo;
    private String companyName;
    private String category;
    private String owner;
    private Date startingDate;
    private Date registrationDate;
    private int capital;

    public Companies() {
    }

    public Companies(int registrationNo, String companyName, String category, String owner, Date startingDate, Date registrationDate, int capital) {
        this.registrationNo = registrationNo;
        this.companyName = companyName;
        this.category = category;
        this.owner = owner;
        this.startingDate = startingDate;
        this.registrationDate = registrationDate;
        this.capital = capital;
    }

    public int getRegistrationNo() {
        return registrationNo;
    }

    public void setRegistrationNo(int registrationNo) {
        this.registrationNo = registrationNo;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public Date getStartingDate() {
        return startingDate;
    }

    public void setStartingDate(Date startingDate) {
        this.startingDate = startingDate;
    }

    public Date getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(Date registrationDate) {
        this.registrationDate = registrationDate;
    }

    public int getCapital() {
        return capital;
    }

    public void setCapital(int capital) {
        this.capital = capital;
    }
    
    
}
